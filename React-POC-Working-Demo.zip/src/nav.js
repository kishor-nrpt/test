import React from "react";
import { Link } from "react-router-dom";

const Navbar = (props) => {
  return (
    <div>
      <table width="100%" border="0">
        <tr>
          <td align="left">
            <img
              className="App-logo-calyx"
              src="https://static.mytrials-dev.pii.pxl.int/images/e-logo_pi-mytrials.jpg"
              alt="logo"
            />
          </td>
          <td align="left">
            <div className="App-Nav">
              <Link to="/dashboard">Dashboard</Link> &nbsp; &nbsp;
              <Link to="/reports">Reports</Link> &nbsp; &nbsp;
              <Link to="/logout">Logout</Link> &nbsp; &nbsp;
            </div>
          </td>
        </tr>
      </table>
    </div>
  );
};

export default Navbar;
