export const styles = {
  color: "blue",
};
