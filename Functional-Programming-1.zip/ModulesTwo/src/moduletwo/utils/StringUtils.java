package moduletwo.utils;

public class StringUtils {

	public String toUpperCase(String value) {
		return value.toUpperCase();
	}
	
}
