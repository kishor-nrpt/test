module ModulesOne {
	exports modulesone.print;
}