package modulesone.print;

public class PrintStringValue {
	
	
	public void printValue(String value) {
		System.out.println(value);
	}

}
