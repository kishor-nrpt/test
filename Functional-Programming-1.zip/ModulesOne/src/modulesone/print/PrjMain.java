package modulesone.print;

public class PrjMain {

	public static void main(String[] args) {
	System.out.println("Sub Module");
	

	}

}
