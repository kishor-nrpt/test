package modules.main;
import modulesone.print.*;
import moduletwo.utils.StringUtils;
public class MainModule {

	
	public static void main(String[] args) {
		PrintStringValue prt = new PrintStringValue();
		StringUtils utils = new StringUtils();
		prt.printValue(utils.toUpperCase("test"));
		PrjMain prjMain = new PrjMain();
		prjMain.main(args);
	}

}
