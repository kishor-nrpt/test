package javaconecpts;

import java.io.IOException;

class Parent{
	String message = "This is parent";
	public String printMsg() {
		return message;
	}
	
	private Number amount() throws Exception {
		return 14f;
	}
	
	public void test(int test) throws Exception{
		System.out.println(test);
	}
	
}

class Child extends Parent{
	String message = "This is child";
	public String printMsg() {
		return message;
	}
	
	Float amount() throws ArithmeticException{
		return 15f;
	}
	
	public String amount(int val) {
		return String.valueOf(val);
	}
	
	private int test(int test, int test1){
		 return 0;
	}
	
	
}



public class polymorphism {
	public static void main(String[] args) {
		Parent p1 = new Parent();
		Child c1= new Child();
		Parent p2=new Child();
		
		System.out.println(p1.printMsg());
		System.out.println(c1.printMsg());
		System.out.println(p2.printMsg());
	}
	
	

}
