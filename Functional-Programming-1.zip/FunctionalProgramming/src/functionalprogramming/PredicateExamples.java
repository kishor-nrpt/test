package functionalprogramming;

public class PredicateExamples {
	
	public static void main(String args[]) {
		System.out.println(LambdaExpressions.evenOrOdd.test(2));
		System.out.println(LambdaExpressions.greater.test(2, 3));
		System.out.println(LambdaExpressions.sumGreaterThan.test(2, 3, 4));
	}

}


