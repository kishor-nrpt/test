package functionalprogramming;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortingOfList {

	private static List<Integer>intList = new ArrayList<>();
	private static List<Character>charList = new ArrayList<>();
	private static List<String>stringList = new ArrayList<>();
	private static List<Person> personList = new ArrayList<>();
	
	public static void main(String args[])
	{
		stringList =  InitiazilierBuilderClass.getStringList();
		intList = InitiazilierBuilderClass.getIntList();
		charList = InitiazilierBuilderClass.getCharList();
		personList = InitiazilierBuilderClass.getPersonList();
		
		System.out.println("-----Values-------");
		//stringList.stream().sorted(Comparator.comparing(String::toString)).forEach(System.out::println);
		stringList.stream().sorted().forEach(System.out::println);
		System.out.println("-----------------");
		intList.stream().sorted().forEach(System.out::println);
		System.out.println("-----------------");
		personList.stream().sorted(Comparator.comparing(Person::getAge)).forEach(System.out::println);
		System.out.println("-----------------");
		personList.stream().sorted().forEach(System.out::println);
		System.out.println("-----------------");
		personList.stream().sorted(new PersonNameComparator().reversed()).collect(Collectors.toList()).forEach(System.out::println);
	}
	
}
