package functionalprogramming;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class TerminalOperations {
	
	public static <R> Predicate<R> not(Predicate<R> predicate) {
	    return predicate.negate();
	}
	
	
	public static void main(String args[]) {
		List<Integer> intList = InitiazilierBuilderClass.getIntList();
		Stream.of(1, 2, 3, 4, 5, 6, 7).filter(not(c -> c * 2 == 0));
		
		intList.stream().map(LambdaExpressions.addByOne.andThen(LambdaExpressions.multiplier)).sorted()
		.filter(LambdaExpressions.evenOrOdd).collect(Collectors.toList()).forEach(System.out::println);
		System.out.println("---------------");
		System.out.println(intList.stream().mapToInt(Integer::intValue).sum());
		System.out.println("---------------");
		Optional<Integer> intValue= Optional.of(intList.stream().reduce(0,(a,b) -> a+b).intValue());
		
		System.out.println(intList.stream().reduce(0,(a,b) -> a+b).intValue());
		
		int val = IntStream.rangeClosed(0, 4).boxed().reduce((a,b) -> a+b).get();
		
		System.out.println("Sum of hundred "+val);
		
	}

}
