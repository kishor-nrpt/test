package functionalprogramming;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ParellelStreams {
	
	public static void main(String args[]) {
		List<Integer> intList = new ArrayList<>();
		
		for(int i=0;i<30000000;i++) {
			intList.add(i);
		}
		
		
		Long t3 = System.currentTimeMillis();
		intList.stream().map(x -> x*1).collect(Collectors.toList());
		Long t4 = System.currentTimeMillis();
		System.out.println("-------------");
		System.gc();
		Long t1 = System.currentTimeMillis();
		intList.stream().parallel().map((x) -> x*1).collect(Collectors.toList());
		Long t2 = System.currentTimeMillis();
		System.out.println("-------------");
		
		System.out.println("Parallel Time difference "+ (t2-t1));
		System.out.println("Sequence Time difference "+ (t4-t3));
		
		
		
		/*
		 * parallelStreams = intList.stream(); t1 = System.currentTimeMillis();
		 * parallelStreams.forEach(System.out::print); t2 = System.currentTimeMillis();
		 */
		
		
		
	}

}
