package functionalprogramming;

public interface VarArgInterface<T, R> {
	
	R apply(T... args);

}
