package functionalprogramming;

public class ListOfEvens {
	
}
