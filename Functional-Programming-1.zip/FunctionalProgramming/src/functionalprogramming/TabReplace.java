package functionalprogramming;

public class TabReplace {

	
	public static void main(String[] args) {
		String str="	Test ";
		System.out.println(str.replaceAll("\t", "*"));
		System.out.println(str);
	}
}
