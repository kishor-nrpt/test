package functionalprogramming;

import java.util.function.BiFunction;
import java.util.function.Function;

public class FunctionAsReturn {
	
	final static BiFunction<Integer , Integer, Integer> add = (x,y) -> x+y;
	
	public static Integer selfMultipliesOne(Integer v1){
		return v1*1;
	}
	
	public static Integer selfMultipliesTwo(Integer v1){
		return v1*2;
	}
	
	public static Integer selfMultipliesThree(Integer v1){
		return v1*3;
	}
	
	public static Integer selfMultipliesFour(Integer v1){
		return v1*4;
	}
	
	public static Function<Integer,Integer> createMultiplier(Integer y){
		return x ->x*y;
	}
	
	public static Function<Integer,Function<Integer,Integer>> createMultiplier1 = (y) ->(x) ->x*y;
	
	public static BiFunction<Integer,Integer, BiFunction<Integer,Integer,Integer>> createOperation = (x,y) -> (a,b) -> a*b*x*y;
	
	public static BiFunction<Integer,Integer, Integer> createOperation1(Integer x, Integer y) {
		return (a,b) -> a*b*x*y;
	} 
	
	public BiFunction<Integer, Integer, Integer> combine(Integer v1,Integer v2, BiFunction<Integer, Integer, Integer> operation) {
		return (x,y) -> operation.apply(v1, v2)*x*y;
	}
	
	
	
	
	
}
