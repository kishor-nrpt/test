package functionalprogramming;

public interface NoArgsFunction<R> {
	R apply();
	
}
