package functionalprogramming;

import java.io.Serializable;

public class SerializationClass implements Serializable{

	private static final long serialVersionUID = 1L;
	private String name;
	private String password;
	private String department;
	private String salary;
	private String test;
	
	public SerializationClass(String name, String password, String department) {
		this.name=name;
		this.password=password;
		this.department=department;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}
	
	
}
