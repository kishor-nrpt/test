package functionalprogramming;

public interface InterfaceTwo {
	default String doWrite() {
		return "Returning from Interface Two";
	}
	
	public static String interfMethod() {
		return "From Interface Two static method";
	}
	
	private String buildString() {
		return "This is private method";
	}
}
