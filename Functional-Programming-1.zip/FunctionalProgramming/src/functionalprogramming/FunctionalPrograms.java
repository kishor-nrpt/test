package functionalprogramming;

import java.util.function.BiFunction;

public class FunctionalPrograms {
	
	
	private Integer add(Integer v1, Integer v2) {
		return v1+v2;
	}
	
	private Integer sub(Integer v1, Integer v2) {
		return v1-v2;
	}

}
