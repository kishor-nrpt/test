import logo from "./logo.svg";
import "./App.css";
import React, { Component } from "react";
import SelfSignUp from "./container/selfsignup.component";
import Navbar from "./nav";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Dashboard from "./dashboard";

class App extends Component {
  value = "test ";
  pageDetails = {
    logoURL:
      "https://static.mytrials-dev.pii.pxl.int/images/e-logo_pi-mytrials.jpg",
    pageHeader: "Welcome to Calyx",
    formHeader: "User Self Registration Form",
  };
  styles = {
    color: "red",
  };

  textChange = () => {
    console.log("tet");
    this.value = "test 1";
  };

  render() {
    return (
      <div className="App">
        <img
          src={this.pageDetails.logoURL}
          className="App-logo-Calyx"
          alt="logo"
        />

        <header className="App-header">
          <a
            className="App-link"
            href="https://www.calyx.ai/"
            target="_blank"
            rel="noopener noreferrer"
          >
            {this.pageDetails.pageHeader}
          </a>
        </header>

        {/* <BrowserRouter>
          <Navbar />
          <Routes>
            <Route path="/dashboard" element={<Dashboard />}></Route>
          </Routes>
        </BrowserRouter> */}

        <body className="App-body">
          <br />
          <SelfSignUp pageHeader="User Self Registration Form" />
        </body>
      </div>
    );
  }
}

export default App;
