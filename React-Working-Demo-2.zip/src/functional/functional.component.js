import React, { Component } from "react";

const Component1 = (props) => {
  return React.createElement("div", { className: "App" }, props.name);
};

export default Component1;
