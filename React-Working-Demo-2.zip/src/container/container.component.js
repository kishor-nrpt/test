import React, { Component } from "react";

class ContainerComp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value1: "Initial Value",
      value2: "Secondary Value",
      increment: 1,
    };
  }

  changeValues = () => {
    if (this.state.value1 === "Initial Value") {
      this.setState({ value1: "Secondary Value" });
    } else {
      this.setState({ value1: "Initial Value" });
    }
    this.setState((prevState, prop) => ({
      increment: prevState.increment + 1,
    }));
  };
  render() {
    return React.createElement(
      "div",
      { className: "App" },
      this.state.value1,
      ", ",
      <br />,
      <button onClick={() => this.changeValues()}>change value</button>,
      ": ",
      <div>{this.state.increment}</div>
    );
  }
}

export default ContainerComp;
