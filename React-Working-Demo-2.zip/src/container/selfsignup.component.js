import React, { Component } from "react";
import { Link } from "react-router-dom";

class SelfSignUp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstname: "",
      lastname: "",
      email: "",
      address1: "",
      address2: "",
    };

    this.firstNameChange = this.firstNameChange.bind(this);
    this.lastNameChange = this.lastNameChange.bind(this);
    this.emailChange = this.emailChange.bind(this);
    this.address1Change = this.address1Change.bind(this);
    this.address2Change = this.address2Change.bind(this);

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  firstNameChange(event) {
    this.setState({ firstname: event.target.value });
  }

  lastNameChange(event) {
    this.setState({ lastname: event.target.value });
  }

  emailChange(event) {
    this.setState({ email: event.target.value });
  }

  address1Change(event) {
    this.setState({ address1: event.target.value });
  }

  address2Change(event) {
    this.setState({ address2: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault();
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <div>
          <h4>{this.props.pageHeader}</h4>
        </div>
        <table>
          <tr>
            <td>
              <label>First Name:</label>
            </td>
            <td>
              <label>
                <input
                  type="text"
                  value={this.state.firstname}
                  onChange={this.firstNameChange}
                />
              </label>
            </td>
          </tr>

          <tr>
            <td>
              <label>Last Name:</label>
            </td>
            <td>
              <label>
                <input
                  type="text"
                  value={this.state.lastname}
                  onChange={this.lastNameChange}
                />
              </label>
            </td>
          </tr>

          <tr>
            <td>
              <label>Email:</label>
            </td>
            <td>
              <label>
                <input
                  type="text"
                  value={this.state.email}
                  onChange={this.emailChange}
                />
              </label>
            </td>
          </tr>

          <tr>
            <td>
              <label>Address One:</label>
            </td>
            <td>
              <label>
                <textarea
                  value={this.state.address1}
                  onChange={this.address1Change}
                />
              </label>
            </td>
          </tr>

          <tr>
            <td>
              <label>Address Two:</label>
            </td>
            <td>
              <label>
                <textarea
                  value={this.state.address2}
                  onChange={this.address2Change}
                />
              </label>
            </td>
          </tr>

          <tr>
            <td colSpan={2}>
              <Link to="/dashboard">
                <input type="submit" value="Submit" />
              </Link>
            </td>
          </tr>
        </table>
      </form>
    );
  }
}

export default SelfSignUp;
