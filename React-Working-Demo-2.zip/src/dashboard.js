import { Component } from "react";
import Navbar from "./nav";

class Dashboard extends Component {
  render() {
    return (
      <div>
        <div className="App-body">
          <Navbar />
          Welcome to Dashboard
        </div>
      </div>
    );
  }
}

export default Dashboard;
