import {MatTableDataSource} from '@angular/material/table';
export function convertSnaps<T>(results:any){
   return results.docs.map((snap: { id: any; data: () => any; }) => {return {id:snap.id,...<any>snap.data()}});
}

export function parseResponseToMatTableDatasource<T>(response: any){
   response=new MatTableDataSource(response);
   return response;
}