import { Pipe,PipeTransform } from "@angular/core";
import { observable, Observable } from "rxjs";

@Pipe({
    name: 'unique',
    pure: true
})

export class UniqueFilter implements PipeTransform{

    transform(list: any,...filter:any): any {
        
        list = JSON.parse(list);
        let filteredData =[];
        
        for(var val of list){
            if(!filteredData.includes(val.seqNo)){
                console.log("## "+val)
                filteredData.push(val);
            }else{
                console.log("else"+JSON.stringify(val))
            }
            
        }
        console.log("Filtered data "+filteredData)
        
        return  JSON.stringify(filteredData);
    }

}