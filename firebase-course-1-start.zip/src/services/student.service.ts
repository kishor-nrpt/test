import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";
import { StudentDetails } from "src/app/model/student_details.model";

@Injectable({
    providedIn:"root"
})
export class StudentService{
 
private _url="./assets/data/studentsdata.json";
constructor(private httpClient: HttpClient){

}

getStudentsData():Observable<StudentDetails[]>{
    return this.httpClient.get<StudentDetails[]>(this._url).pipe(catchError(this.errorHandler));
}
errorHandler(error: HttpErrorResponse)
{
    
    console.log("Error logged "+error.message)
    return throwError(error.message) || null;
}

}