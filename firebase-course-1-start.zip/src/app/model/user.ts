export class User{
    name:string
    age:number
    gender:string;
    employed:boolean;
    genderOptions:string[] = ['Male','Female'];

    constructor(name:string,age:number,gender:string,employed:boolean) {
        this.name=name;
        this.age=age;
        this.gender=gender;
        this.employed=employed;
       // this.genderOptions=['Male','Female'];
    }
}