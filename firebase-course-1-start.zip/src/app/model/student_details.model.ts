export interface StudentDetails
{
    name:string;
    class:string;
    No_Of_Students:string;
}