import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { StudentService } from "src/services/student.service";
import { StudentDetails } from "../model/student_details.model";


@Component({
    selector: 'ChidComponent',
    templateUrl: './child.html',
    styleUrls: ['./parent.css']
})
export class ChildComponent implements OnInit{

//@Input('fromParent') public parentMsg;
@Input('fromParent') public parentMsg;
@Output() public fromChild = new EventEmitter();
public childMsg="unhide"


public studentDetails: any;

constructor(private studentService:StudentService){

}

toParent(){
    this.childMsg=(this.parentMsg =='hide'?'unhide':'hide');
    this.fromChild.emit(this.childMsg);
}

getStudentDetails(student:StudentDetails){
    console.log(student);
    return false;
}

ngOnInit(){
 this.studentService.getStudentsData().subscribe(snaps => {
    this.studentDetails = <StudentDetails[]>snaps;
});  
}

}

