import { Component, OnInit } from "@angular/core";
import { Event } from "@angular/router";

@Component({
    selector: 'ParentComponent',
    templateUrl: './parent.html',
    styleUrls: ['./parent.css']
})
export class ParentComponent implements OnInit{

    public parentMsg:string = "hide";
    public childMsg:string = "unhide";
    ngOnInit() {
       
      } 
      
      ngOnChanges(){
          console.log("on Change event called")
      }


      fromChildEvent(eventMsg:string){
          this.childMsg=(eventMsg === 'hide'?'unhide':'hide');
          this.parentMsg=eventMsg;
        
      }

}