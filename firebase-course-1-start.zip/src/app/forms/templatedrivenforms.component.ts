import { Component } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import {FormControl, FormGroup} from '@angular/forms';

import "node_modules/bootstrap/dist/css/bootstrap.css"
import { User } from "../model/user";

@Component({
    selector: 'templatedrivenform',
    templateUrl: './templatedrivenforms.html',
    styleUrls: ['./templatedrivenforms.css']
})


export class TemplateDrivenFormComponent{
    
 public user:User;
 public myForm:FormBuilder;
 public style_IsItalic:boolean=true;
 public style:boolean=false;
 public styleGroup={
     "TextStyle":this.style,
     "TextColor":this.style,
     "TextSize":this.style
 }
  constructor(){
      this.user = new User('Arun',30,'Male',true)
  }
}