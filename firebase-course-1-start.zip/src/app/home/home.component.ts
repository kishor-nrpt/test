import {Component, OnInit, ViewChild} from '@angular/core';
import {Course} from '../model/course';
import {Observable, of} from 'rxjs';
import {AngularFirestore} from '@angular/fire/firestore';
import {Router} from '@angular/router';
import { CourseService } from 'src/services/course.service';
import { MatSort } from '@angular/material/sort';
import {parseResponseToMatTableDatasource } from 'src/utils/db-utils';
import {MatIconModule} from '@angular/material/icon';
@Component({
    selector: 'home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})


export class HomeComponent implements OnInit {
    
    @ViewChild(MatSort) matsort: MatSort;
    
    beginnersCourses$: Observable<Course[]>;
    advancedCourses$: Observable<Course[]>;
    courseData:any;
    courses:any;
    gridView:boolean=false;
   
    // tableColumns  :  string[] = ['id','categories','lessonsCount','description','price','iconUrl','url','courseListIcon','seqNo','longDescription'];
    tableColumns  :  string[] = ['seqNo','course','lessonsCount','price'];
   
    constructor(
      private router: Router,
      private courseService:CourseService) {

    }

    ngOnInit() {
      this.reloadCourses('BEGINNER');
    } 

    reloadCourses(courseType:string){
      if(courseType === 'BEGINNER' ){
        this.beginnersCourses$ = this.courseService.loadCoursesByCategory(courseType);
        this.beginnersCourses$.toPromise().then(response => {
          this.courses=response;
          this.courseData = parseResponseToMatTableDatasource(response);
          this.courseData.sort = this.matsort;
        });
      }else if(courseType === 'ADVANCED'){
        this.advancedCourses$ = this.courseService.loadCoursesByCategory(courseType);
        this.advancedCourses$.toPromise().then(response => 
          {
            this.courses=response;
            this.courseData = parseResponseToMatTableDatasource(response);
            this.courseData.sort = this.matsort;
          });
      }

    }

    tabClick(event){
      let courseFor:string;
      courseFor=event.tab.textLabel.toUpperCase();
      this.reloadCourses(courseFor);
    }

}
