import {Component, OnInit} from '@angular/core';


import 'firebase/firestore';

import {AngularFirestore} from '@angular/fire/firestore';
import {COURSES, findLessonsForCourse} from './db-data';



@Component({
    selector: 'about',
    templateUrl: './about.component.html',
    styleUrls: ['./about.component.css']
})
export class AboutComponent {

    constructor(private db: AngularFirestore) {
    }

    async uploadData() {
        const coursesCollection = this.db.collection('courses');
        const courses = await this.db.collection('courses').get();
        for (let course of Object.values(COURSES)) {
            const newCourse = this.removeId(course);
            const courseRef = await coursesCollection.add(newCourse);
            const lessons = await courseRef.collection('lessons');
            const courseLessons = findLessonsForCourse(course['id']);
            console.log(`Uploading course ${course['description']}`);
            for (const lesson of courseLessons) {
                const newLesson = this.removeId(lesson);
                delete newLesson.courseId;
                await lessons.add(newLesson);
            }
        }
    }

    onReadDocs(){
        this.db.doc("/courses/IpwpkTQnk9KWDC6MECad").get().subscribe(snap => {
            console.log(snap.id);
            console.log(snap.data());
        })
    }
    onReadCollections(){
        this.db.collection("courses").get().subscribe(snaps =>{
            snaps.forEach(snap =>{
                
                console.log(snap.exists);
                if(snap.exists){
                    console.log(snap.id);
                    console.log(snap.data())
                }
            })
        })
    }

    onReadLessons(){
        this.db.collection("/courses/ADmUsSoyNLRiVGvAFFCu/lessons").get().subscribe(snaps => {
            snaps.forEach(snap => {
                console.log(snap.id);
                console.log(snap.data());
            })
        });
    }
    removeId(data: any) {
        const newData: any = {...data};
        delete newData.id;
        return newData;
    }
    onConditionalSelect(){
        this.db.collection("courses",ref => ref.where("seqNo","<=",1).orderBy("seqNo")).get().subscribe(snaps => {
            snaps.forEach(snap => {
                console.log(snap.data());
            })
        });
    }

    onConditionalMultiSelect(){
        this.db.collection("courses",ref => ref.where("seqNo","<=",5).where("lessonsCount","==",10)).get().subscribe(snaps => {
            snaps.forEach(snap => {
                console.log(snap.data());
            });
        });
    }

    onNestedCollection(){
        this.db.collectionGroup("lessons",ref => ref.where("seqNo","==",1)).get().subscribe(snaps => {
            snaps.forEach(snap => {
                console.log(snap.data());
            })
        })
    }

    onRealTimeValueChange1(){
        this.db.doc("/courses/IpwpkTQnk9KWDC6MECad")
               .valueChanges()
               .subscribe(snap => {
            console.log(snap);
        })
    }

    onRealTimeValueChange2(){
        this.db.doc("/courses/IpwpkTQnk9KWDC6MECad")
               .snapshotChanges()
               .subscribe(snap => {
                console.log(snap.payload.data());
        })
    }

}
















