import { Component, Input, OnInit } from "@angular/core";

@Component({
    selector: 'student-app',
    templateUrl: './student.component.html',
    styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit{

    @Input('studentList') public students :any[];

    ngOnInit(){
        console.log("Tes")
    }

}