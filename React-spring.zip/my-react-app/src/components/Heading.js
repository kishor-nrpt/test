import React from "react";
import { Link } from "react-router-dom";
// import { Navbar, Nav, NavItem, NavbarBrand, Container } from "reactstrap";
export const Heading = () => {
  return (
    <div>
     
      <Link to="/add" id="addUserLink" className="btn btn-primary">
        Add User
      </Link>
    </div>
  );
};
