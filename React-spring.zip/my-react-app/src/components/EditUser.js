import { Form, FormGroup, Label, Input, Button } from "reactstrap";
import { Link } from "react-router-dom";
import { useLocation, useNavigate } from "react-router";

import React, { useState } from "react";
import UserService from "../service/UserService";

export const EditUser = () => {
  const { state } = useLocation();

  let navigate = useNavigate();
  const [firstName, setFirstName] = useState(state.firstName);
  const [lastName, setLastName] = useState(state.lastName);
  const [title, setTitle] = useState(state.title);
  // const toast = useRef(null);
  const [formErrors, setFormErrors] = useState({});

  const validate = (values) => {
    const errors = {};
    if (!values.title) {
      errors.title = "Title is required!";
    }

    if (!values.firstName) {
      errors.firstName = "First name is required!";
    } else if (values.firstName.length < 4) {
      errors.firstName = "First name should be more than 3 characters";
    }

    if (!values.lastName) {
      errors.lastName = "Last name is required!";
    }

    return errors;
  };

  const onFirstNameChange = (e) => {
    setFirstName(e.target.value);
  };

  const onLastNameChange = (e) => {
    setLastName(e.target.value);
  };
  const onTitleChange = (e) => {
    setTitle(e.target.value);
  };

  const onSubmit = (e) => {
    e.preventDefault();

    var data = {
      title: title,
      firstName: firstName,
      lastName: lastName,
    };

    let errors = validate(data);
    setFormErrors(errors);
    console.log(Object.keys(errors).length);

    if (Object.keys(errors).length === 0) {
      UserService.update(state.id, data)
        .then((response) => {
          // console.log(response.data);
          setTitle("");
          setFirstName("");
          setLastName("");
          navigate("/");
        })
        .catch((e) => {
          console.log(e);
        });
    }
  };

  return (
    <div>
      <Form onSubmit={onSubmit}>
        <FormGroup>
          <Label>Title</Label>
          <Input type="select" value={title} onChange={onTitleChange}>
            <option value="">Select Title</option>
            <option>Mr</option>
            <option>Mrs</option>
            <option>Dr</option>
            <option>Miss</option>
            <option>Ms</option>
          </Input>
          <p style={{ color: "red" }}>{formErrors.title}</p>
        </FormGroup>
        <FormGroup>
          <Label>First Name</Label>
          <Input
            type="text"
            placeholder="Enter First Name"
            value={firstName}
            onChange={onFirstNameChange}
          ></Input>
          <p style={{ color: "red" }}>{formErrors.firstName}</p>
        </FormGroup>
        <FormGroup>
          <Label>Last Name</Label>
          <Input
            type="text"
            placeholder="Enter Last Name"
            value={lastName}
            onChange={onLastNameChange}
          ></Input>
          <p style={{ color: "red" }}>{formErrors.lastName}</p>
        </FormGroup>
        <Button type="submit" className="btn btn-success">
          Submit
        </Button>
        <Link to="/" className="btn btn-danger ml-2">
          Cancel
        </Link>
      </Form>
    </div>
  );
};
