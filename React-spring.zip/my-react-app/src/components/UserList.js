import React from "react";
import { useEffect, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { FilterMatchMode } from "primereact/api";
import UserService from "../service/UserService";
import { ContextMenu } from "primereact/contextmenu";
import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Toast } from "primereact/toast";

export const UserList = () => {
  let navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [first, setFirst] = useState(0);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);

  const columns = [
    { field: "title", header: "Title", sortable: false },
    { field: "firstName", header: "First Name", sortable: true },
    { field: "lastName", header: "Last Name", sortable: true },
  ];

  const filters = {
    title: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    firstName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    lastName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
  };

  const menuModel = [
    {
      label: "Edit",
      icon: "pi pi-fw pi-search",
      command: () => editUser(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-times",
      command: () => deleteUser(selectedProduct),
    },
  ];

  const editUser = (user) => {
    // console.log(user);
    navigate("/edit/" + user.id, { state: user });
  };

  const deleteUser = (user) => {
    UserService.delete(user.id)
      .then((response) => {
        console.log(response);
        let usersList = [...users];
        usersList = usersList.filter((u) => u.id !== user.id);
        toast.current.show({severity: 'success', summary: 'User Deleted', detail: user.firstName});
        setUsers(usersList);
      })
      .catch((e) => {
        console.log(e);
      });
  };
  useEffect(() => {
    UserService.getAll()
      .then((response) => {
        setUsers(response.data);
        console.log(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }, []);

  const dynamicColumns = columns.map((col, i) => {
    return (
      <Column
        key={col.field}
        field={col.field}
        header={col.header}
        sortable={col.sortable}
        filter
      />
    );
  });

  return (
    <div>
      <Toast ref={toast}></Toast>
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={users}
        paginator
        rows={5}
        first={first}
        filters={filters}
        filterDisplay="row"
        onPage={(e) => setFirst(e.first)}
        size="small"
        selectionMode="single"
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
      >
        {dynamicColumns}
      </DataTable>
    </div>
  );
};
