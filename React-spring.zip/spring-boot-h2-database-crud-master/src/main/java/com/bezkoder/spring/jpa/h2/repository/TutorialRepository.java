package com.bezkoder.spring.jpa.h2.repository;

import java.util.List;

import com.bezkoder.spring.jpa.h2.model.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TutorialRepository extends JpaRepository<User, Long> {
//    List<User> findByPublished(boolean published);
//
//    List<User> findByTitleContaining(String title);
}
