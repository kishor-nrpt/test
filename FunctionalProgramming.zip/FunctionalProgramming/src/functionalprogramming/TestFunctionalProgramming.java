package functionalprogramming;

import java.util.function.BiFunction;
import java.util.function.Function;


public class TestFunctionalProgramming {
	
	public static BiFunction<Float , Float, Float> dividerValidator;
	public static BiFunction<Integer, Integer, Integer> biFunction;
	
	public static void main(String[] args) {
		
		FunctionAsReturn funcAsReturn = new FunctionAsReturn();
		HigherOrderFunction higherOrderFunction =new HigherOrderFunction();
		
		System.out.println(LambdaExpressions.person.apply());
		System.out.println(LambdaExpressions.addThree.apply(1, 2, 3));
		System.out.println(LambdaExpressions.func.apply(1, 0));
		System.out.println("Function as argument "+new FunctionAsArg<Integer, Integer, Integer>().combine(3,4,LambdaExpressions.add));
		System.out.println("Function as argument "+new FunctionAsArg<String, String, String>().combine("a","b",LambdaExpressions.concatString));

		Function<Integer,Integer> funcRes=funcAsReturn.createMultiplier(3);
		System.out.println(funcRes.apply(3));	
		
		Function<Integer,Integer> funcRes1=funcAsReturn.createMultiplier1.apply(4);
		System.out.println(funcRes1.apply(3));
		
		BiFunction<Integer , Integer, Integer> res =funcAsReturn.createOperation.apply(2, 3);
		res.apply(3, 3);
		res = funcAsReturn.createOperation1(2, 3);
		res.apply(3, 3);
		
		res = funcAsReturn.combine(1, 2, LambdaExpressions.add);
		res.apply(1, 2);
		System.out.println(res.apply(1, 2));
		System.out.println();
		
		dividerValidator =higherOrderFunction.validator.apply(LambdaExpressions.divider);
		Float resF = dividerValidator.apply(2f, 2f);
		System.out.println("Higher value "+resF);
		
		dividerValidator = higherOrderFunction.exceptionHandler.apply(LambdaExpressions.divider);
		System.out.println(dividerValidator.apply(1f, 0f));
		
		LambdaExpressions.printMessage.apply("a","b", "c");
	}

}
