package functionalprogramming;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class StreamOperations {
	
	public static void main(String[] args) {
		List<String> list = Arrays.asList("A","B","C","D");
	    Optional<String> result = list.stream().findAny();
	    System.out.println(result.isPresent());
	    System.out.println(result.get());
	    new StreamOperations().patternTest();
	   
	}
	
	public void patternTest() {
		String REGEX = "geeks";
		  
        // create the string
        // in which you want to search
        String actualString
            = "Welcome to geeks for geeks";
        String s[] =actualString.split(REGEX);
        
        Stream.of(s).forEach(System.out::println);
  
        // create a Pattern using REGEX
        Pattern pattern = Pattern.compile(REGEX);
  
        // split the text
        Stream<String> stream = pattern.splitAsStream(actualString);
  
        // print array
       // stream.forEach(System.out::println);
        
        
        Pattern p = Pattern.compile(REGEX);
        p.splitAsStream(REGEX).findAny();
        
        String s1[] =p.split(REGEX);
        
        
	}

}
