package functionalprogramming;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;

public interface LambdaExpressions {
	
	public static Predicate<Integer> evenOrOdd= (x) ->   (x%2 == 0) ? true:false;
	public static Function<Integer,Integer> multiplier = (x) -> x*2;
	public static Function<Integer,Integer> addByOne = (x) -> x+1;
	public static BiPredicate<Integer, Integer> greater =(x,y) -> x>y ?true:false;
	public static TriPredicate<Integer,Integer, Integer> sumGreaterThan =(x,y,z) -> x+y>z?true:false;
	public final static BiFunction<Float, Float, Float> divider = (x,y) ->x/y;
	public final static BiFunction<Integer,Integer,Integer> func= (x,y) -> x-y; 
	public final static TriFunction<Integer, Integer, Integer, Integer> addThree = (x,y,z) -> x+y+z;
	public final static NoArgsFunction<Person> person= new Person().dataLoader(true);
	public final static BiFunction<String,String,String> concatString  = (v1,v2) -> v1+" "+v2;
	public final static BiFunction<Integer , Integer, Integer> add = (x,y) -> x+y;
	public final static BiFunction<Integer , Integer, Integer> sub = (x,y) -> x-y;
	public final static TriFunction<String, String, String,String> concatMessage =(x,y,z) -> new StringBuffer().append(x).append(y).append(z).toString();
	public final static TriConsumer<String, String, String> printMessage =(x,y,z) -> System.out.println(x+y+z);; 
	
	
}
