package functionalprogramming;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerilizationTest {

	private String fileName="C:\\Users\\bondila\\Workspace\\POC\\Test.ser";
	SerializationClass serObj= new SerializationClass("Arun", "Test", "IT");
	SerializationPojo serP =new SerializationPojo();
	
	private String  testString= "This is Test String";
	
	private void writeObjectSerialization() throws Exception{
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		//oos.writeChars("TEST");
		oos.writeObject(serObj);
	}
	
	private void readObjectSerialization() throws Exception{
		FileInputStream fis = new FileInputStream(fileName);
		ObjectInputStream ois = new ObjectInputStream(fis);
		SerializationPojo serObj1 = (SerializationPojo) ois.readObject();
		System.out.println(serObj1.getName() +"::"+serObj1.getPassword());
		
	}
	
	public static void main(String[] args) {
		try {
			SerilizationTest obj= new SerilizationTest();
			//obj.writeObjectSerialization(); 
			obj.readObjectSerialization();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
