package functionalprogramming;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EvenNumbersInList implements LambdaExpressions{
	
	private static List<Integer>intList = new ArrayList<>();
	private static List<Character>charList = new ArrayList<>();
	private static List<String>stringList = new ArrayList<>();
	
	public static void main(String args[]) {
		intList = InitiazilierBuilderClass.getIntList();
		intList.stream().filter(LambdaExpressions.evenOrOdd).collect(Collectors.toList()).forEach(System.out::println);
		intList.stream().map(LambdaExpressions.multiplier).collect(Collectors.toList()).forEach(System.out::println);
		
	}

}
