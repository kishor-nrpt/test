package functionalprogramming;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;


public class SumOfValuesInList {
	

	private static List<Integer>intList = new ArrayList<>();
	private static List<Character>charList = new ArrayList<>();
	private static List<String>stringList = new ArrayList<>();
	
	public static void main(String args[])
	{
		intList = InitiazilierBuilderClass.getIntList();
		int r=intList.stream().reduce((x,y) -> LambdaExpressions.add.apply(x, y)).get();
		System.out.println(r);
		
        r=intList.stream().reduce((x,y) -> LambdaExpressions.sub.apply(x, y)).get();
		System.out.println(r);
		
		r = intList.stream().collect(Collectors.summingInt(Integer::intValue));
		System.out.println(r);
		
		List<Integer> numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);

		IntSummaryStatistics stats = numbers.stream().mapToInt(Integer::intValue).summaryStatistics();
		System.out.println(stats);
	}
}
