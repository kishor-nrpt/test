package functionalprogramming;

import java.util.function.BiFunction;
import java.util.function.Function;

public class HigherOrderFunction {
	
	
	final static Function<BiFunction<Float, Float, Float>,BiFunction<Float, Float, Float>> validator
	  = (func) ->(x,y)->(y<=0f ? 0f :func.apply(x, y));
	
	  final static Function<BiFunction<Float, Float, Float>,BiFunction<Float, Float, Float>> exceptionHandler = (func)
			->(x,y) ->{
				try{
					return func.apply(x,y);
				}
				catch(Exception e) {
					return -1f;
				}
			};
	}
