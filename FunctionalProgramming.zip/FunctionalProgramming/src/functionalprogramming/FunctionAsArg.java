package functionalprogramming;

import java.util.function.BiFunction;

public class FunctionAsArg<T, V, R> {
	
	public R combine(T t,V v,BiFunction<T, V, R> operation) {
		return (R)operation.apply(t, v);
	}
}
