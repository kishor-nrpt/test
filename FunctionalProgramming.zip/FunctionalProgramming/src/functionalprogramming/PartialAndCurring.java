package functionalprogramming;

import java.util.function.BiFunction;
import java.util.function.Function;

public class PartialAndCurring {
	
	public static void main(String args[]) {
		
		TriFunction<Integer, Integer, Integer, Integer> add = (x,y,z) -> x+y+z;

		BiFunction<Integer,Integer,Function<Integer,Integer>> partialFunc1 = (x,y) -> (z) -> add.apply(x,y,z);
		
		Function<Integer, Integer> partialFunc2 =  partialFunc1.apply(5,6);
		
		System.out.println(partialFunc2.apply(3));
		
		
	}

}
