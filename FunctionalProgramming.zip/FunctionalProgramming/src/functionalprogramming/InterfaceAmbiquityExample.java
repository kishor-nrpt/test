package functionalprogramming;

public class InterfaceAmbiquityExample implements InterfaceOne, InterfaceTwo {

	@Override
	public String doWrite() {
		// TODO Auto-generated method stub
		return InterfaceTwo.super.doWrite();
	}
	
	public static void main(String[] args) {
		System.out.println(new InterfaceAmbiquityExample().doWrite());
		System.out.println(InterfaceTwo.interfMethod());
	}

}
