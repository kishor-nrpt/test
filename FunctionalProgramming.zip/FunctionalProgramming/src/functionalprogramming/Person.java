package functionalprogramming;

import java.util.Comparator;

public class Person implements Comparable<Person>{
	
	private int age;
	private String name ;
	private NoArgsFunction<Person> person;
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Person(int age, String name) {
		this.age=age;
		this.name=name;
	}
	
	public Person() {
		
	}
	
	protected Person isRealPerson() {
		return new Person(100,"Real Person");
	}
	
	protected Person isFakePerson() {
		return new Person(100,"Fake Person");
	}

	public  NoArgsFunction<Person> dataLoader(boolean isDev) {
		this.person= isDev ? this::isFakePerson:this::isRealPerson;
		return person;
	}
	
	public String toString() {
		return this.name+" "+this.age;
	}

	@Override
	public int compareTo(Person o1) {
		return this.age>o1.getAge() ? 1 :this.age == o1.getAge() ? 0: -1;
	}
	
	
}

