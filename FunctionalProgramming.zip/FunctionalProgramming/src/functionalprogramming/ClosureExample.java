package functionalprogramming;

import java.util.function.BiFunction;
import java.util.function.Function;

public class ClosureExample {

	public static void main(String args[]) {

		Function<String,String> func1=(a)->{
			String b="b";
			return a+b;
		};
		
		Function<String,String> func2=(c) ->{
			return func1.apply(c);
		};
		//while calling the func2.apply it has access to variable b. This is nothing but closure
		System.out.println(func2.apply("a"));
		
		
		//PartialAppliedFunction and Curring
		//Calling a function with fixed value 
		
		TriFunction<Integer, Integer, Integer, Integer> add = (x,y,z) ->x+y+z;
		
		Function<Integer,BiFunction<Integer, Integer, Integer>> fixIndex = (x) -> (y,z) -> add.apply(x, y, z);
		
		BiFunction<Integer, Integer, BiFunction<Integer,Integer,Integer>> callingFunc = (x,y)  ->  fixIndex.apply(5);
		
		BiFunction<Integer, Integer, Integer> callingFunc1 = callingFunc.apply(6, 7);
		
		//System.out.println(callingFunc1.apply(8, 4));
		
		
		QuadFunction<Integer, Integer, Integer, Integer,Integer> quadFunc = (w,x,y,z) -> w+x+y+z;
		
		TriFunction<Integer, Integer, Integer, Function<Integer, Integer>> triFunc = (w,x,y) -> (u) -> quadFunc.apply(w,x,y, 4);
		
		BiFunction<Integer, Integer, Function<Integer,Integer>> biFunc = (x,y) -> triFunc.apply(x, y, 3);
		
		System.out.println(biFunc.apply(1, 2));
		
		
		
	}
	
	
}
