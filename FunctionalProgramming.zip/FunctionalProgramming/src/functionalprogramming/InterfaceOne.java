package functionalprogramming;

public interface InterfaceOne {
	
	default String doWrite() {
		return "Returning from Interface One";
	}

}
