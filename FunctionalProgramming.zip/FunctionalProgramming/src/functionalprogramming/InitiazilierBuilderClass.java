package functionalprogramming;

import java.util.ArrayList;
import java.util.List;

public class InitiazilierBuilderClass {

	
	private static List<Integer>intList = new ArrayList<>();
	private static List<Character>charList = new ArrayList<>();
	private static List<String>stringList = new ArrayList<>();
	private static List<Person> personList = new ArrayList<>();
	
	static {
		
		intList.add(7);
		intList.add(5);
		intList.add(1);
		intList.add(6);
		intList.add(4);
		intList.add(8);
		intList.add(3);
		intList.add(2);

		
		charList.add('c');
		charList.add('f');
		charList.add('a');
		charList.add('d');
		charList.add('g');
		charList.add('b');
		charList.add('e');
		charList.add('h');
		
		stringList.add("one");
		stringList.add("two");
		stringList.add("three");
		stringList.add("four");
		stringList.add("five");
		stringList.add("six");
		stringList.add("seven");
		stringList.add("eight");
		stringList.add("nine");
		stringList.add("ten");
		
		personList.add(new Person(10, "Person 10"));
		personList.add(new Person(5, "Person 5"));
		personList.add(new Person(9, "Person 9"));
		personList.add(new Person(40, "Person 40"));
		personList.add(new Person(37, "Person 37"));
		personList.add(new Person(56, "Person 56"));
		personList.add(new Person(61, "Person 61"));
		personList.add(new Person(21, "Person 21"));
		personList.add(new Person(4, "Person 4"));
		personList.add(new Person(75, "Person 75"));

		
	}

	public static List<Integer> getIntList() {
		return intList;
	}

	public static void setIntList(List<Integer> intList) {
		InitiazilierBuilderClass.intList = intList;
	}

	public static List<Character> getCharList() {
		return charList;
	}

	public static void setCharList(List<Character> charList) {
		InitiazilierBuilderClass.charList = charList;
	}

	public static List<String> getStringList() {
		return stringList;
	}

	public static void setStringList(List<String> stringList) {
		InitiazilierBuilderClass.stringList = stringList;
	}

	public static List<Person> getPersonList() {
		return personList;
	}

	public static void setPersonList(List<Person> personList) {
		InitiazilierBuilderClass.personList = personList;
	}
	
}
