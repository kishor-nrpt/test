package functionalprogramming;

public interface TriConsumer<T,U,V> {
	public void apply(T t, U u,V v);

}
