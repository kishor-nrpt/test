import React from "react";

export const HeaderBanner = () => {
  const pageDetails = {
    logoURL:
      "https://static.mytrials-dev.pii.pxl.int/images/e-logo_pi-mytrials.jpg",
    pageHeader: "Welcome to Calyx",
    formHeader: "Enter your login details",
  };

  return (
    <React.Fragment>
      <img src={pageDetails.logoURL} className="App-logo-Calyx" alt="logo" />

      <header className="App-header">
        <a
          className="App-link"
          href="https://www.calyx.ai/"
          target="_blank"
          rel="noopener noreferrer"
        >
          {pageDetails.pageHeader}
        </a>
      </header>
    </React.Fragment>
  );
};
