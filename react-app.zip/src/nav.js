import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const headerColor = {
  backgroundColor: "skyBlue",
};

const Navbar = (props) => {
  const [selectedUtil, setUtil] = useState("-");
  const navigate = new useNavigate();
  //const [selectedOption] = useState(props.selectedOption);
  //setUtil(selectedOption);
  const routeToUtil = (event) => {
    setUtil(event.target.value);
    let selectedVal = event.target.value;
    console.log("selected " + selectedVal);
    if (selectedVal === "calculator") {
      resetValues();
      navigate("/calculator/test?q=matlab");
    } else if (selectedVal === "musicplayer") {
      resetValues();
      navigate("/musicplayer/", { state: "User Preffered Music" });
    } else {
      return false;
    }
  };

  const resetValues = () => {
    setUtil("");
  };

  return (
    <div style={{ backgroundColor: "skyblue" }}>
      <table width="100%" border="0">
        <tbody>
          <tr>
            <td align="left">
              <img
                className="App-logo-calyx"
                src="https://static.mytrials-dev.pii.pxl.int/images/e-logo_pi-mytrials.jpg"
                alt="logo"
              />
            </td>
            <td align="left">
              <div className="App-Nav" style={headerColor}>
                <Link to="/dashboard">Dashboard</Link> &nbsp; &nbsp;
                <Link to="/reports">Reports</Link> &nbsp; &nbsp;
                <select value={selectedUtil} onChange={routeToUtil}>
                  <option value="-">Utils</option>
                  <option value="calculator">Calculator</option>
                  <option value="musicplayer">Music Player</option>
                </select>
                <Link to="/">Logout</Link> &nbsp; &nbsp;
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Navbar;
