import { forwardRef, useImperativeHandle, useState } from "react";
import { Button } from "reactstrap";

const ChildButton = forwardRef((props, ref) => {
  const [toggle, setToggle] = useState(false);
  useImperativeHandle(ref, () => ({
    toggleEvnt: () => {
      setToggle(!toggle);
    },
  }));
  return (
    <>
      <div className="col-md-12">
        <Button onClick={() => setToggle(!toggle)}>Child Event</Button>
        {toggle && <div>Toggle Text</div>}
      </div>
    </>
  );
});
export default ChildButton;
