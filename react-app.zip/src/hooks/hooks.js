import Header from "../header";
import React, {
  useReducer,
  useState,
  useEffect,
  useRef,
  useLayoutEffect,
} from "react";
import {
  Button,
  CardBody,
  CardHeader,
  Input,
  InputGroupText,
  Row,
} from "reactstrap";
import ParentComp from "./parent.component";
import LoginApp from "../UseContextHook/LoginApp";

const reducer = (state, action) => {
  switch (action.type) {
    case "INCREMENT":
      return { count: state.count + 1, showText: state.showText };
    case "DECREMENT":
      return { count: state.count - 1, showText: state.showText };
    case "TOGGLETEXT":
      return { count: state.count, showText: !state.showText };
    default:
      return { count: state.count, showText: state.showText };
  }
};

const Hooks = () => {
  const [state, dispatch] = useReducer(reducer, { count: 0, showText: false });

  const inputRef = useRef(null);
  const clickEvnt = () => {
    inputRef.current.value = "";
    console.log(inputRef.current.value);
    inputRef.current.focus();
  };

  useEffect(() => {
    console.log("useEffect executed once when page is renders completely ");
  }, []);

  useLayoutEffect(() => {
    console.log("useEffect executed once when page starts renders");
  }, []);

  useEffect(() => {
    console.log(
      "useEffect executed once when page is renders completely but conditional basis "
    );
  }, [state.count]);
  return (
    <>
      <Header headerPage={"Calculator"} />
      <div className="container" style={{ padding: "10px" }}>
        <CardBody>
          <div className="col-md-12">useReducer hook</div>
          <Row>
            <div className="col-md-6">
              <InputGroupText>{state.showText && <p>Hello</p>} </InputGroupText>
              <InputGroupText> {state.count} </InputGroupText>
            </div>
            <div className="col-md-6">
              <Button
                size="m"
                onClick={() => {
                  dispatch({ type: "INCREMENT" });
                }}
              >
                INCREMENT
              </Button>
              <br />
              <Button
                size="m"
                onClick={() => {
                  dispatch({ type: "TOGGLETEXT" });
                }}
              >
                Toogle Text
              </Button>
            </div>
          </Row>
          <Row>
            <div className="col-md-12">
              useEffect hook
              <br />
              Conditional use effect: Un Conditional use effect:
            </div>
          </Row>
        </CardBody>
      </div>
      <div className="container" style={{ padding: "10px" }}>
        <div className="col-md-12">
          <CardHeader tag="h4">Use Ref</CardHeader>
          <CardBody>
            This Hook is used to auto focus
            <Input type="text" innerRef={inputRef} />
            <Button onClick={clickEvnt}>Clear and focus</Button>
          </CardBody>
        </div>
      </div>
      <div className="container" style={{ padding: "10px" }}>
        <div className="col-md-12">
          <CardHeader tag="h4">Forward Ref</CardHeader>
          <CardBody>
            This hook is used for Parent to Child
            <br />
            <ParentComp />
          </CardBody>
        </div>
      </div>
      <div className="container" style={{ padding: "10px" }}>
        <div className="col-md-12">
          <CardHeader tag="h4">Context API</CardHeader>
          <CardBody>
            <LoginApp />
          </CardBody>
        </div>
      </div>
    </>
  );
};

export default Hooks;
