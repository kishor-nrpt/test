import { useRef } from "react";
import { Button } from "reactstrap";
import ChildButton from "./child.button";

const ParentComp = () => {
  const buttonRef = useRef(false);
  return (
    <>
      <Button onClick={() => buttonRef.current.toggleEvnt()}>
        Parent Button
      </Button>
      <ChildButton innerRef={buttonRef} ref={buttonRef} />
    </>
  );
};

export default ParentComp;
