import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";
import ReactLogo from "../images/logo192.png";
import AudioFile from "../sound/sample-15s.mp3";
import MusicLogo from "../images/music_logo_1.png";
import SampleVideo1 from "../video/Sample-Video-1.mp4";
import SampleVideo2 from "../video/Sample-Video-2.mp4";
import { Card, CardBody, CardHeader, Row } from "reactstrap";
import Header from "../header";

const Musicplayer = () => {
  const location = new useLocation();
  useEffect(() => {
    console.log(location);
  });

  return (
    <>
      <Card>
        <Header headerPage={"Music"} />
        <CardHeader className="text-center bg-dark text-white">
          <label>
            <img
              className="card-img-top"
              src={ReactLogo}
              aria-label="Logo"
              style={{ width: "100px" }}
            />
          </label>
        </CardHeader>
        <CardBody className="text-center">
          <legend>
            <div className="container">
              <Row>
                <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 col-xxl-4 border">
                  <label>
                    <img
                      className="card-img-top "
                      src={MusicLogo}
                      aria-label="Sound Sample"
                      style={{ width: "150px", height: "200px" }}
                    />
                  </label>
                  <br />
                  <label>
                    <audio controls>
                      <source src={AudioFile} type="audio/ogg" />
                    </audio>
                  </label>
                </div>
                <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 col-xxl-4 border">
                  <label>
                    <img
                      className="card-img-top "
                      src={MusicLogo}
                      aria-label="Sound Sample"
                      style={{ width: "150px", height: "200px" }}
                    />
                  </label>
                  <br />
                  <label>
                    <audio controls>
                      <source src={AudioFile} type="audio/ogg" />
                    </audio>
                  </label>
                </div>
                <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 col-xxl-4 border">
                  <label>
                    <img
                      className="card-img-top "
                      src={MusicLogo}
                      aria-label="Sound Sample"
                      style={{ width: "150px", height: "200px" }}
                    />
                  </label>
                  <br />
                  <label>
                    <audio controls>
                      <source src={AudioFile} type="audio/ogg" />
                    </audio>
                  </label>
                </div>
              </Row>
              <Row>
                <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 border text-center">
                  <video controls height={600} width={550}>
                    <source src={SampleVideo1} type="video/mp4" />
                  </video>
                </div>
                <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 border text-center">
                  <video controls height={600} width={550}>
                    <source src={SampleVideo2} type="video/mp4" />
                  </video>
                </div>
              </Row>
            </div>
          </legend>
        </CardBody>
      </Card>
    </>
  );
};

export default Musicplayer;
