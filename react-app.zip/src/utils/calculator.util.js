import { event } from "jquery";
import React, { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import ReactLogo from "../images/logo192.png";
import SoundSrc from "../sound/sample-15s.mp3";

import {
  Alert,
  Button,
  Card,
  CardBody,
  CardFooter,
  Form,
  Input,
  InputGroup,
  InputGroupText,
  Row,
} from "reactstrap";
import Header from "../header";

const Calculator = () => {
  let location = useLocation();
  const { name } = useParams();
  const [pageData, setPageValues] = useState({
    input: "",
  });
  const { input } = pageData;
  const [invalidInputFlag, setInvalidInputFlag] = useState([]);
  const sp = new URLSearchParams(location.search);
  const onDataChange = (e) => {
    setPageValues({ ...pageData, [e.target.name]: e.target.value });
  };
  useEffect(() => {
    console.log(location);
    console.log(name);
    console.log(sp.has("q")); // true
    console.log(sp.get("q"));
  });
  const inputClicked = (e) => {
    try {
      let val = e.target.innerText;
      if (val === "clear") {
        setPageValues({ ...pageData, input: "0" });
      } else if (val === "=") {
        setPageValues({ ...pageData, input: eval(input) });
      } else if (input === "0") {
        setPageValues({ ...pageData, input: val });
      } else {
        setPageValues({ ...pageData, input: input + val });
      }
      setInvalidInputFlag("false");
    } catch (error) {
      console.log(error);
      setPageValues({ ...pageData, input: "0" });
      setInvalidInputFlag("true");
    }
  };
  return (
    <React.Fragment>
      <Row>
        <Header headerPage={"Calculator"} />
        <Card>
          <CardBody>
            <div className="container">
              <InputGroup>
                <InputGroupText>{"name"}</InputGroupText>
                <Input
                  placeholder="Input"
                  onChange={onDataChange}
                  value={input}
                  name="input"
                />
              </InputGroup>
              <br />
            </div>
            <div className="container mb-2">
              <div className="col-md-3" style={{ padding: "10px" }}>
                <Button
                  size="lg"
                  color="primary"
                  variant="primary"
                  outline={true}
                  onClick={inputClicked}
                >
                  1
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  variant="primary"
                  outline={true}
                  onClick={inputClicked}
                >
                  2
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  outline={true}
                  variant="primary"
                  onClick={inputClicked}
                >
                  3
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  outline={true}
                  variant="primary"
                  onClick={inputClicked}
                >
                  +
                </Button>{" "}
              </div>
              <div className="col-md-3" style={{ padding: "10px" }}>
                <Button
                  size="lg"
                  color="primary"
                  variant="primary"
                  outline={true}
                  onClick={inputClicked}
                >
                  4
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  variant="primary"
                  outline={true}
                  onClick={inputClicked}
                >
                  5
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  outline={true}
                  variant="primary"
                  onClick={inputClicked}
                >
                  6
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  outline={true}
                  variant="primary"
                  onClick={inputClicked}
                >
                  -
                </Button>{" "}
              </div>
              <div className="col-md-3" style={{ padding: "10px" }}>
                <Button
                  size="lg"
                  color="primary"
                  variant="primary"
                  outline={true}
                  onClick={inputClicked}
                >
                  7
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  variant="primary"
                  outline={true}
                  onClick={inputClicked}
                >
                  8
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  outline={true}
                  variant="primary"
                  onClick={inputClicked}
                >
                  9
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  outline={true}
                  variant="primary"
                  onClick={inputClicked}
                >
                  *
                </Button>{" "}
              </div>
              <div
                className="col-md-3"
                style={{
                  padding: "10px",
                }}
              >
                <Button
                  size="lg"
                  color="primary"
                  variant="primary"
                  outline={true}
                  onClick={inputClicked}
                >
                  0
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  variant="primary"
                  outline={true}
                  onClick={inputClicked}
                >
                  =
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  outline={true}
                  variant="primary"
                  onClick={inputClicked}
                >
                  clear
                </Button>{" "}
                <Button
                  size="lg"
                  color="primary"
                  outline={true}
                  variant="primary"
                  onClick={inputClicked}
                >
                  /
                </Button>{" "}
              </div>
              <div className="col-md-3" style={{ padding: "10px" }}>
                {invalidInputFlag === "true" ? (
                  <Alert>Invalid Input</Alert>
                ) : (
                  ""
                )}
              </div>
            </div>
          </CardBody>
          <CardFooter>
            <InputGroup>
              <InputGroupText>All rights reserved</InputGroupText>
            </InputGroup>
          </CardFooter>
        </Card>
      </Row>
    </React.Fragment>
  );
};

export default Calculator;
