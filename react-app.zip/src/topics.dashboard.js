import { React, useState } from "react";
import {
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  FormGroup,
  Row,
} from "reactstrap";

const TopicsDashboard = () => {
  const [state, setStateValues] = useState({
    dropdownOpen: true,
  });
  const { dropdownOpen } = state;
  const noRefCheck = () => {
    setStateValues({ ...state, dropdownOpen: !dropdownOpen });
  };
  return (
    <>
      <div className="container">
        <div className="col-md-3">
          <div className="d-flex justify-content-center p-5">
            <Dropdown isOpen={dropdownOpen} toggle={noRefCheck}>
              <DropdownToggle caret>Dropdown</DropdownToggle>
              <DropdownMenu>
                <DropdownItem header>Header</DropdownItem>
                <DropdownItem>Some Action</DropdownItem>
                <DropdownItem text>Dropdown Item Text</DropdownItem>
                <DropdownItem disabled>Action (disabled)</DropdownItem>
                <DropdownItem divider />
                <DropdownItem>Foo Action</DropdownItem>
                <DropdownItem>Bar Action</DropdownItem>
                <DropdownItem>Quo Action</DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </div>
        </div>
        <div className="col-md-3"></div>
        <div className="col-md-3"></div>
        <Row>
          <FormGroup></FormGroup>
        </Row>
      </div>
    </>
  );
};
export default TopicsDashboard;
