import React, { useState } from "react";
import {
  Button,
  CardHeader,
  Input,
  InputGroup,
  InputGroupText,
} from "reactstrap";

const UnControlledComponent = (props) => {
  // const [inputText, setInputText] = props.inputText;
  //const inputText] = useState(props.inputText);
  return (
    <>
      <CardHeader tag="h3">Un-Controlled component</CardHeader>
      <div className="container col-md-3">
        <InputGroup>
          <Input placeholder="Input" onChange={props.setValue} type="number" />
        </InputGroup>
      </div>
    </>
  );
};
export default UnControlledComponent;
