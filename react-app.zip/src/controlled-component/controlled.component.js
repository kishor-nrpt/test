import React, { useState } from "react";
import {
  Button,
  CardHeader,
  Input,
  InputGroup,
  InputGroupText,
} from "reactstrap";
import UnControlledComponent from "./uncontrolled.component";

const ControlledComponent = () => {
  const [inputText, setInputText] = useState(0);

  const setValue = () => {
    setInputText(inputText + 1);
  };

  return (
    <>
      <CardHeader tag="h3">Controlled component</CardHeader>
      <div className="container col-md-3">
        <InputGroupText>{inputText}</InputGroupText>
        <InputGroup>
          <Input
            placeholder="Input"
            onChange={setValue}
            value={inputText}
            type="number"
            name="inputText"
          />
          <Button onClick={setValue}>Increment</Button>
        </InputGroup>
      </div>
      <div className="container">
        <UnControlledComponent setValue={setValue}></UnControlledComponent>
      </div>
    </>
  );
};
export default ControlledComponent;
