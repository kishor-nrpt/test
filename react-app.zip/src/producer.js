import React from "react";
import Consumer from "./consumer";
import Header from "./header";
export const UserContext = React.createContext();

const Producer = () => {
  return (
    <>
      <Header headerPage="Producer" />
      <UserContext.Provider value="This is from Producer using useContext">
        <Consumer />
      </UserContext.Provider>
    </>
  );
};

export default Producer;
