import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React, { Component } from "react";
import SelfSignUp from "./container/selfsignup.component";
import LoginComponent from "./login/login.component";
import { HeaderBanner } from "./header-banner";

class App extends Component {
  value = "test ";
  pageDetails = {
    logoURL:
      "https://static.mytrials-dev.pii.pxl.int/images/e-logo_pi-mytrials.jpg",
    pageHeader: "Welcome to Calyx",
    formHeader: "Enter your login details",
  };
  styles = {
    color: "red",
  };

  textChange = () => {
    this.value = "test 1";
  };

  render() {
    return (
      <React.Fragment>
        <HeaderBanner />
        <div className="App-body">
          <br />
          <LoginComponent pageHeader="Enter your login details" />
        </div>
      </React.Fragment>
    );
  }
}

export default App;
