import Header from "./header";

const Reports = () => {
  const courseAry = ["HMTL", "JavaScript", "JQuery", "Angular", "React JS"];
  const filterdCourseAry = courseAry.filter((name) => name.includes("J"));

  return (
    <div className="App-body">
      <Header headerPage="Reports" />
      <div>
        {courseAry.map((value, index) => (
          <li key={index}>{value}</li>
        ))}
      </div>
      ==========
      <div>
        {filterdCourseAry.map((name, index) => (
          <li key={index}>{name}</li>
        ))}
      </div>
    </div>
  );
};
export default Reports;
