import React, { useEffect } from "react";
import { useContext } from "react";
import Header from "./header.js";
import { UserContext } from "./producer.js";

const Consumer = () => {
  const context = React.useContext(UserContext);
  console.log(context);
  return (
    <>
      <UserContext.Consumer>
        {(value) => (
          <div>
            {value !== null ? value : <Header headerPage={"Consumer"} />}
          </div>
        )}
      </UserContext.Consumer>
    </>
  );
};

export default Consumer;
