import axios from "axios";

export default axios.create({
  //baseURL: "http://team-avengers-spike-react-app-api-demo.azurewebsites.net",
  baseURL: "http://localhost:8080",
  headers: {
    "Content-type": "application/json",
  },
});
