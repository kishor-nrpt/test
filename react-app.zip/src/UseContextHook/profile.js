import { Button, Card, CardBody, CardHeader } from "reactstrap";
import React, { useContext, useEffect } from "react";
import { LoginContext } from "./LoginContext.js";
const Profile = () => {
  const { username, setUsername, setShowProfile } = useContext(LoginContext);
  useEffect(() => {
    // setShowProfile(true);
  });
  return (
    <>
      <Card>
        <CardHeader tag="h3">Profile</CardHeader>
        <CardBody>
          Hello : {username}
          <br />
          <Button
            onClick={() => {
              setShowProfile(false);
            }}
          >
            Login
          </Button>
        </CardBody>
      </Card>
    </>
  );
};

export default Profile;
