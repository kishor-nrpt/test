import { event } from "jquery";
import { useState, useContext } from "react";
import { LoginContext } from "./LoginContext";
import { Button, Form, Input } from "reactstrap";

const Login = () => {
  const [password, setPassword] = useState("");
  const { username, setUsername, setShowProfile } = useContext(LoginContext);

  return (
    <>
      <Form>
        <div className="Container">
          <div className="border">
            <Input
              type="text"
              name="username"
              value={username}
              onChange={(event) => setUsername(event.target.value)}
            />
          </div>
          <div className="border">
            <Input
              type="password"
              name="password"
              value={password}
              autoComplete={"true"}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          <div className="border">
            <Button
              onClick={() => {
                setShowProfile(true);
              }}
            >
              Login
            </Button>
          </div>
        </div>
      </Form>
    </>
  );
};
export default Login;
