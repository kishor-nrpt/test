import React, { createContext } from "react";

export const LoginContext = React.createContext();
