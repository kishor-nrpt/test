import { useState } from "react";
import { CardBody, Nav, NavItem, NavLink, Row } from "reactstrap";
import Login from "./login";
import Profile from "./profile";
import { LoginContext } from "./LoginContext";
import Header from "../header";
import { Link } from "react-router-dom";

const LoginApp = () => {
  const [showProfile, setShowProfile] = useState(false);
  const [username, setUsername] = useState("");

  return (
    <>
      <Header headerPage="Use Context Hook" />
      <CardBody>
        <div className="container">
          <Row>
            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 border">
              <LoginContext.Provider
                value={{ username, setUsername, setShowProfile }}
              >
                {showProfile ? <Profile /> : <Login />}
              </LoginContext.Provider>
            </div>
            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 col-xxl-6 border">
              <Nav>
                <NavItem>
                  <NavLink active href="#">
                    <Link to={"/producer"}>Producer</Link>
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="#">
                    <Link to={"/consumer"}>Consumer</Link>
                  </NavLink>
                </NavItem>
              </Nav>
            </div>
          </Row>
        </div>
      </CardBody>
    </>
  );
};
export default LoginApp;
