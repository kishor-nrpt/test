import HOC from "./hoc-auth";

const HocProfile = () => {
  return <>You are in Profile Page</>;
};
export default HOC(HocProfile);
