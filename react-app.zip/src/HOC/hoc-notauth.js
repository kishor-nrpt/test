import React from "react";
import { Alert } from "reactstrap";

export const NoAuth = () => {
  return <Alert>Invalid Input</Alert>;
};
