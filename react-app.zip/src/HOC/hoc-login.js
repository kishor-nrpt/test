import HOC from "./hoc-auth";

const HocLogin = () => {
  return <>You are in Login Page</>;
};
export default HOC(HocLogin);
