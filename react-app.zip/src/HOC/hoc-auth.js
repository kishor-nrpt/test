import React from "react";
import { NoAuth } from "./hoc-notauth";

const HOC = (Component) => {
  return class extends React.Component {
    state = {
      auth: false,
    };
    render() {
      return this.state.auth ? <Component /> : <NoAuth />;
    }
  };
};

export default HOC;
