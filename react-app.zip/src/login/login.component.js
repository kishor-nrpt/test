import React, { useState } from "react";
import { Form, FormGroup, Label, Input, Button } from "reactstrap";
import { Link, useNavigate } from "react-router-dom";
import userService from "../services/userservice.component";

const LoginComponent = () => {
  let navigate = useNavigate();

  const [loginData, setLoginData] = useState({
    username: "",
    password: "",
  });

  const { username, password } = loginData;

  const onChange = (e) => {
    setLoginData({ ...loginData, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();

    var submitData = {
      username: username,
      password: password,
    };

    userService
      .login(submitData)
      .then((response) => {
        navigate("/userlist");
      })
      .catch((e) => {
        console.log(e);
        alert("Invalid Username/Password");
      });
  };

  return (
    <div>
      <Form onSubmit={onSubmit}>
        <FormGroup>
          <Label>User Name</Label>
          <Input
            type="text"
            autoComplete="yes"
            placeholder="Enter User Name"
            value={username}
            name="username"
            onChange={onChange}
          ></Input>
        </FormGroup>
        <FormGroup>
          <Label>Password</Label>
          <Input
            autoComplete="yes"
            type="password"
            name="password"
            placeholder="Enter Password"
            value={password}
            onChange={onChange}
          ></Input>
        </FormGroup>
        <FormGroup>
          <Button type="submit" className="btn btn-success">
            Submit
          </Button>
          {"  "}
          <Link to="/" className="btn btn-danger ml-2">
            <Button type="Button" className="btn btn-success">
              Cancel
            </Button>
          </Link>
        </FormGroup>
        <FormGroup>
          <Link to="/selfsign">New User ?</Link> {"  "}
          <Link to="/forgotpassword">Forgot Password ?</Link>
        </FormGroup>
      </Form>
    </div>
  );
};

export default LoginComponent;
