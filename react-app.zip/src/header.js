import { useState } from "react";
import { Card, CardHeader, CardTitle } from "reactstrap";
import Navbar from "./nav";

const Header = (props) => {
  const [name] = useState(props.inputText);

  return (
    <div>
      <Navbar />
      <Card className="text-center">
        <CardHeader tag="h3">{name}</CardHeader>
      </Card>
      <br />
    </div>
  );
};

export default Header;
