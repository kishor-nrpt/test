import { useEffect, useState } from "react";
import axios from "axios";
import Header from "./header";
import { Link } from "react-router-dom";

const Dashboard = () => {
  const [count, setCount] = useState(0);
  const [hcount, setHcount] = useState(0);
  const [email, setEmail] = useState("");
  const [data, setData] = useState({
    landiline: "",
    cell: "",
  });

  const { landiline, cell } = data;
  const onChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("submitted");
    axios.get("/reports", data);
  };
  useEffect(() => {
    console.log("This is use effet count");
  }, [count]);

  const emailHandler = (e) => setEmail(e.target.value);

  useEffect(() => {
    console.log("This is use effet");
  }, []);

  return (
    <div className="App-body" style={{ textAlign: "left" }}>
      <Header headerPage={"Dashboard"} />
      <p>
        useState Example
        <br />
        <button
          type="button"
          onMouseEnter={() => {
            setHcount(hcount + 1);
          }}
          onClick={() => {
            setCount(count + 1);
          }}
        >
          Click
        </button>
        {count}
        <br />
        Hover {hcount}
      </p>
      <br />
      ========================================================
      <br />
      <h4>Enter the details</h4>
      <form onSubmit={handleSubmit}>
        <p>
          <label>
            Email{" "}
            <input
              type="text"
              name="email"
              value={email}
              onChange={emailHandler}
            ></input>
          </label>
          <br />
          <label>
            Phone Number{" "}
            <input
              name="cell"
              value={cell}
              type="number"
              onChange={onChange}
            ></input>
          </label>
          <br />
          <label>
            Landline Number{" "}
            <input
              name="landiline"
              value={landiline}
              onChange={onChange}
              type="number"
            ></input>
          </label>
          <br />
          <input type="submit" value="Submit" />
        </p>
        <br />
        ========================Use Context
        Example================================
        <br />
        <Link to="/producer">Producer</Link> <br />
        <Link to="/consumer">Consumer</Link>
        <br />
        <Link to="/usecontextLogin" />
        <br />
        <Link to="/loginAppContext" />
        <br />
        <Link to="/usecontextProfile" />
        <br />
        <Link to="/hoclogin" HocLogin />
        <br />
        <Link to="/hocprofile" HocProfile />
        <br />
        ================================
        <br />
        ============================
        <br />
      </form>
    </div>
  );
};

export default Dashboard;
