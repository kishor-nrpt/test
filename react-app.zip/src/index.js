import "bootstrap/dist/css/bootstrap.min.css";
import $ from "jquery";
import Popper from "popper.js";
import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Dashboard from "./dashboard";
import Reports from "./reports";
import SelfSignUp from "./container/selfsignup.component";
import { UserList } from "./user/UserList";
import { AddUser } from "./user/AddUser";
import Calculator from "./utils/calculator.util";
import Musicplayer from "./utils/music-player";
import Producer from "./producer";
import Consumer from "./consumer";
import Login from "./UseContextHook/login";
import { LoginContext } from "./UseContextHook/LoginContext";
import Profile from "./UseContextHook/profile";
import LoginApp from "./UseContextHook/LoginApp";
import HocLogin from "./HOC/hoc-login";
import HocProfile from "./HOC/hoc-profile";
import ControlledComponent from "./controlled-component/controlled.component";
import UnControlledComponent from "./controlled-component/uncontrolled.component";
import Hooks from "./hooks/hooks";
import TopicsDashboard from "./topics.dashboard";

ReactDOM.render(
  <React.StrictMode>
    <div styles="">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<App />}></Route>
          <Route path="/dashboard" element={<Dashboard />}></Route>
          <Route path="/reports" element={<Reports />}></Route>
          <Route path="/selfsign" element={<SelfSignUp />}></Route>
          <Route path="/userlist" element={<UserList />}></Route>
          <Route path="/adduser" element={<AddUser />}></Route>
          <Route path="/calculator/:name" element={<Calculator />}></Route>
          <Route path="/musicplayer" element={<Musicplayer />}></Route>
          <Route path="/producer" element={<Producer />}></Route>
          <Route path="/consumer" element={<Consumer />}></Route>
          <Route path="/usecontextLogin" element={<Login />}></Route>
          <Route path="/loginAppContext" element={<LoginApp />}></Route>
          <Route path="/usecontextProfile" element={<Profile />}></Route>
          <Route path="/hoclogin" element={<HocLogin />}></Route>
          <Route path="/hocprofile" element={<HocProfile />}></Route>
          <Route path="/hooks" element={<Hooks />}></Route>
          <Route path="/topicsdashboard" element={<TopicsDashboard />}></Route>
          <Route
            path="/controlledcomponent"
            element={<ControlledComponent />}
          ></Route>
          <Route
            path="/uncontrolledcomponent"
            element={<UnControlledComponent />}
          ></Route>
        </Routes>
      </BrowserRouter>
    </div>
  </React.StrictMode>,
  document.getElementById("root")
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
