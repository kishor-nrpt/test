import React from "react";
import { useEffect, useState } from "react";
import UserService from "../services/userservice.component";
import { useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import Header from "../header";

export const UserList = () => {
  let navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [first, setFirst] = useState(0);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const tableCSS = {
    marginLeft: "auto",
    marginRight: "auto",
    textAlign: "left",
  };
  const columns = [
    { field: "title", header: "Title", sortable: false },
    { field: "firstName", header: "First Name", sortable: true },
    { field: "lastName", header: "Last Name", sortable: true },
  ];

  const menuModel = [
    {
      label: "Edit",
      icon: "pi pi-fw pi-search",
      command: () => editUser(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-times",
      command: () => deleteUser(selectedProduct),
    },
  ];

  const editUser = (user) => {
    // console.log(user);
    navigate("/edit/" + user.id, { state: user });
  };

  const deleteUser = (user) => {
    UserService.delete(user.id)
      .then((response) => {
        // console.log(response);
        let usersList = [...users];
        usersList = usersList.filter((u) => u.id !== user.id);
        toast.current.show({
          severity: "success",
          summary: "User Deleted",
          detail: user.firstName,
        });
        setUsers(usersList);
      })
      .catch((e) => {
        console.log(e);
      });
  };
  useEffect(() => {
    UserService.getAll()
      .then((response) => {
        setUsers(response.data);
        response.data.map((value, index) => console.log(value.id));
      })
      .catch((e) => {
        console.log(e);
      });
  }, []);

  return (
    <div className="App-body">
      <Header headerPage={"User List"} />
      <table className={tableCSS} width="60%" border="0" text>
        <thead>
          <tr style={{ textAlign: "left" }}>
            <th>ID</th>
            <th>Title</th>
            <th>First Name</th>
            <th>Last Name</th>
          </tr>
        </thead>
        <tbody>
          {users.map((value, index) => (
            <tr key={index} style={{ textAlign: "left" }}>
              <td style={{ width: "10%" }}>{value.id}</td>
              <td style={{ width: "20%" }}>{value.title}</td>
              <td style={{ width: "25%" }}>{value.firstName}</td>
              <td>{value.lastName}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <br />
      <br />
      <div style={{ textAlign: "left" }}>
        <Link to="/selfsign">
          <button type="button" value="Add User" name="Add User">
            Add User
          </button>
        </Link>
      </div>
    </div>
  );
};
