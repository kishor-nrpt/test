package com.example.demo.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.example.demo.users.UserService;

@Service
public class SpringScheduler {

	@Autowired
	UserService userService;

	Logger logger = LoggerFactory.getLogger(SpringScheduler.class);

	@Scheduled(fixedRate = 5000)
	public void addUser() {
		try {
			logger.info("Started");
			userService.addUser();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
