package com.example.demo.users;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserDao {

	
	@Autowired
	UserRepository userRepo;
	
	public void addUser(UserDTO userDto) throws Exception{
			User user = new User();
			BeanUtils.copyProperties(userDto, user);
			userRepo.save(user);
	}
	
	public List<BaseDTO> findAllUsers() {
		
		List<BaseDTO> userList = new ArrayList<>();
		List<User> userEntityList = userRepo.findAll();	
		Collections.copy(userList, userEntityList);
		return userList;
		
	}
	
}
