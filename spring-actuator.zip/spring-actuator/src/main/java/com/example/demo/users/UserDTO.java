package com.example.demo.users;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserDTO implements BaseDTO{
	private Integer id;
	private Boolean status;
	private String firstName;
	private String lastName;
	private Integer age;
	private String dept;
	private float sal;
	
	
	public UserDTO(UserBuilder userBuilder) {
		this.firstName=userBuilder.firstName;
		this.lastName=userBuilder.lastName;
		this.age=userBuilder.age;
		this.sal=userBuilder.sal;
		this.dept=userBuilder.dept;
		this.id=userBuilder.id;
		this.status=userBuilder.status;
	}

}
