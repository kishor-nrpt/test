package com.example.demo.users;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Component
@Repository
public class UserService {
	@Autowired
	UserDao userDao;

	private List<BaseDTO> users = new ArrayList<>();

	public List<BaseDTO> getUsers() {
		loadAllUsers();
		return users;
	}

	
	public void addUser()  throws Exception{

		UserBuilder userBuilder = new UserBuilder();
		userBuilder.setAge(new Random().nextInt(70))
		.setDept("IT").setFirstName("Arun").setLastName("Singh").setSal(new Random().nextInt()).setStatus(Boolean.FALSE);
		UserDTO userDto = userBuilder.build();
		userDao.addUser(userDto);


	}

	private void loadAllUsers() {
//		
//		UserBuilder userBuilder = new UserBuilder();
//		userBuilder.setId(new Random().nextInt(1)).setAge(new Random().nextInt(70))
//		.setDept("IT").setFirstName("Arun").setLastName("Singh").setSal(new Random().nextInt()).setStatus(Boolean.FALSE);
//		UserDTO userDto = userBuilder.build();
		
		users=userDao.findAllUsers();

		
	}	

	public List<BaseDTO> getUsersByStatus(boolean status) {

		return users;
	}
}
