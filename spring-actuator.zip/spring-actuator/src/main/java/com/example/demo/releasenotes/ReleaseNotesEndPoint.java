package com.example.demo.releasenotes;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.boot.actuate.endpoint.annotation.DeleteOperation;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id="release-notes",enableByDefault = true)
public class ReleaseNotesEndPoint {
	
	Map<String,String> map = new LinkedHashMap<>();
	
	@PostConstruct
	public void loadReleaseNotes() {
		map.put("ver1","Version 1. got released");
		map.put("ver2","Version 2. got released");
		System.out.println("Request reached");
	}
	
	
	@ReadOperation
	public Map<String,String> getReleaseNotes(){
		return map;
	}
	
	@ReadOperation
	public String getReleaseVerNotes(@Selector String version){
		return map.get(version);
	}
	
	@WriteOperation
	public void updateReleaseNotes(@Selector String updateVersion,String releaseNotes) throws Exception {
		System.out.println("inside ");
		map.put(updateVersion, releaseNotes); 
	}
	
	@DeleteOperation
	public void deleteReleaseNotes(@Selector String deleteVersion) throws Exception{
		map.remove(deleteVersion);
	}

}
