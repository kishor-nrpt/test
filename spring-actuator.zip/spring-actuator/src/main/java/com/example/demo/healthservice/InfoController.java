package com.example.demo.healthservice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.info.Info.Builder;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.stereotype.Component;

import com.example.demo.users.User;
import com.example.demo.users.UserService;

@Component
public class InfoController implements InfoContributor{

	@Autowired
	UserService userService;
	
	@Override
	public void contribute(Builder builder) {
		// TODO Auto-generated method stub
		builder.withDetail("All Users List", userService.getUsers()).build();
		builder.withDetail("Active Users", userService.getUsersByStatus(true)).build();
		builder.withDetail("Inactive Users", userService.getUsersByStatus(false)).build();
	}
	

}
