package com.example.demo.users;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.boot.autoconfigure.domain.EntityScan;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EntityScan
@Entity
@Table(name="TL_USER") 
public class User implements BaseDTO{
	@Id
	@GeneratedValue
	private Integer id;
	private Boolean status;
	private String firstName;
	private String lastName;
	private Integer age;
	private String dept;
	private float sal;


	
}
