package com.example.demo.healthservice;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id="appcustominfo",enableByDefault = true)
public class CustomEndPoint {

	@ReadOperation
	public ApplicationCustomInformationDTO appCustomInfo() {
		return new ApplicationCustomInformationDTO("202","Custom Information",true);
	}
	
	@WriteOperation
	public ApplicationCustomInformationDTO updateAppCustomInfo(@Selector String code,String name,boolean status) {
		
		return new ApplicationCustomInformationDTO(code,name,status);
	}

}


