package com.example.demo.users;

public interface BaseDTO {

}
