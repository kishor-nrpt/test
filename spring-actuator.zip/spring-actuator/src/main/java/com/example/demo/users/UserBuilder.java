package com.example.demo.users;

public class UserBuilder {
	
	public String firstName;
	public String lastName;
	public Integer age;
	public String dept;
	public float sal;
	public Integer id;
	public boolean status;
	
	public UserBuilder(String firstName, String lastName) {
		this.firstName=firstName;
		this.lastName=lastName;
	} 
	public UserBuilder() {
		super();
	}
	public UserBuilder setFirstName(String firstName) {
		this.firstName=firstName;
		return this;
	}
	
	public UserBuilder setLastName(String lastName) {
		this.lastName=lastName;
		return this;
	}
	
	public UserBuilder setAge(int age) {
		this.age=age;
		return this;
	}
	
	public UserBuilder setDept(String dept) {
		this.dept=dept;
		return this;
	}
	
	public UserBuilder setSal(float sal) {
		this.sal=sal;
		return this;
	}
	
	public UserBuilder setId(int id) {
		this.id=id;
		return this;
	}
	
	public UserBuilder setStatus(boolean status) {
		this.status=status;
		return this;
	}
	
	public UserDTO build() {
		UserDTO userDto = new UserDTO(this);
		return userDto;
	}

}
