package com.example.demo.healthservice;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class HealthService implements HealthIndicator{

	@Override
	public Health health() {
		return isApplicationUp()==true 
				?Health.up().withDetail("202", "Application is up and running").build()
				:Health.down().withDetail("400", "Application is down and not running").build();
	}
	
	
	private boolean isApplicationUp() {
		try {
			URL url = new URL("https://www.google.com");
			URLConnection connection = url.openConnection();
			connection.connect();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
