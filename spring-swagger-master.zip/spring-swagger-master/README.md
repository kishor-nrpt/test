# spring-swagger
How to Generate Rest API Documentation using swagger
