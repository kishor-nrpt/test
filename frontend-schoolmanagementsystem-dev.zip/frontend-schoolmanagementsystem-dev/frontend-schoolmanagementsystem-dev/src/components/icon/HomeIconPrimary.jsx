import React, { Component } from 'react'
import Icon from './Icon'
import BasicIcon from './BasicIcon'


export default class HomeIconPrimary extends Component {
    render() {
        return (
            
                <BasicIcon primary className="fa fa-home"></BasicIcon>
            
        )
    }
}
