import React, { Component } from 'react'

import IconOnly from './IconOnly';

const SearchIconPrimary = () => {

    return (
        <IconOnly primary className="fa fa-search"></IconOnly>
    );
}

export default SearchIconPrimary;
