import React, { Component } from 'react'
import Edit from '../../../assets/icons/icons8/EditIcon.png';

export default class editIcon extends Component {
    render() {
        return (
            <img src={Edit} alt="sorry no image" />
        )
    }
}
