import React, { Component } from 'react'

import IconOnly from './IconOnly';

const PlusIconPrimary = () => {

    return (
        <IconOnly primary className="fa fa-plus"></IconOnly>
    );

}

export default PlusIconPrimary;
