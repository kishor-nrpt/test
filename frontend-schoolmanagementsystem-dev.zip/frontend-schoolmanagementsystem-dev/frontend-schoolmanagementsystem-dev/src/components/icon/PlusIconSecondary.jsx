import React, { Component } from 'react'

import IconOnly from './IconOnly';

const PlusIconSecondary = () => {

    return (
        <IconOnly secondary className="fa fa-plus"></IconOnly>
    );

}

export default PlusIconSecondary;
