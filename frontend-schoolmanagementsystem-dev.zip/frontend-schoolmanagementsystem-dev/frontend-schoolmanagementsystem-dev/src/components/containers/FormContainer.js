import styled from 'styled-components';
import theme from '../../theme/theme';

const FormContainer = styled.div`
    padding:0.3em;
    align-content: center;
    flex-wrap: wrap;
    
    
    
   
   
    
`

export default FormContainer;