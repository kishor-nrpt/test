import React, { Component } from 'react'
import BasicCrumbs from '../components/breadcrumbs/BasicCrumbs'

export default class Breadcrumbs extends Component {
    render() {
        return (
            <div>
                <BasicCrumbs/>
            </div>
        )
    }
}
