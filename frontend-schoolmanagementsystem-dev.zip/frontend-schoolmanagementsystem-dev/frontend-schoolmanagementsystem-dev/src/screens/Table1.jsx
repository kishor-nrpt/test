import React, { Component } from 'react'
import { Table, TableHead, TableRow, TableHeading, Tablebody } from '../components/table/Table1'
import editIcon from '../components/icon/table/editIcon'

class Table1Show extends Component {
    render() {
        return (

            <Table>

                <TableRow heading>
                    <TableHead>Firstname</TableHead>
                    <TableHead>Firstname</TableHead>
                    <TableHead>Firstname</TableHead>
                    <TableHead>Firstname</TableHead>
                    <TableHead>Firstname</TableHead>
                    <TableHead>Actions</TableHead>
                    <TableHead>Actions</TableHead>
                </TableRow>

                <TableRow >
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody><img src="https://img.icons8.com/metro/15/000000/edit-property.png" />
                    </Tablebody>
                    <Tablebody><img src="https://img.icons8.com/material/22/000000/delete-forever--v2.png" />
                    </Tablebody>
                </TableRow>
                <TableRow >
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody><img src="https://img.icons8.com/metro/15/000000/edit-property.png" />
                    </Tablebody>
                    <Tablebody><img src="https://img.icons8.com/material/22/000000/delete-forever--v2.png" />
                    </Tablebody>
                </TableRow>
                <TableRow>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody><img src="https://img.icons8.com/metro/15/000000/edit-property.png" />
                    </Tablebody>
                    <Tablebody><img src="https://img.icons8.com/material/22/000000/delete-forever--v2.png" />
                    </Tablebody>
                </TableRow>
                <TableRow >
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody><img src="https://img.icons8.com/metro/15/000000/edit-property.png" />
                    </Tablebody>
                    <Tablebody><img src="https://img.icons8.com/material/22/000000/delete-forever--v2.png" />
                    </Tablebody>
                </TableRow>
                <TableRow>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody><img src="https://img.icons8.com/metro/15/000000/edit-property.png" />
                    </Tablebody>
                    <Tablebody><img src="https://img.icons8.com/material/22/000000/delete-forever--v2.png" />
                    </Tablebody>
                </TableRow>
                <TableRow >
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody>Jill</Tablebody>
                    <Tablebody><img src="https://img.icons8.com/metro/15/000000/edit-property.png" />
                    </Tablebody>
                    <Tablebody><img src="https://img.icons8.com/material/22/000000/delete-forever--v2.png" />
                    </Tablebody>
                </TableRow>

            </Table>

        )
    }
}

export default Table1Show;