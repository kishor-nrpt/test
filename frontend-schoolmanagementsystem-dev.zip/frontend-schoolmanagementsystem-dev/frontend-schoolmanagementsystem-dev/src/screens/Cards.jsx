import React, { Component } from 'react'
import PrimaryCard from '../components/cards/PrimaryCard'



export default class Cards extends Component {
    render() {
        return (
            <div>
                <PrimaryCard />

            </div>
        )
    }
}
